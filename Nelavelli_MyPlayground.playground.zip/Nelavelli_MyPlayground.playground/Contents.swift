import UIKit

var greeting = "Hello, playground"
var i = 10;
print(i)

print("Hello", 10, 12.54)

var name = "chandu"
print("Hello \(name)")

var age = 23
print("My age is \(age) and in the next \(age) years it will be \(age * 2)")
print("My age is", age , "and in the next", age , "years it will be", (age * 2))

print("Hello, \(name)!")

print("""
Hello,
\(name)!
""")

print("Hello \rworld!")

//Explicit declaration of data type
var str : String = "Hello!"
print(str)

let  welcomeMessage : String = "Hello!"
   print(welcomeMessage , "All")

print("Welcome to Swift Programming")
print("Fall 2021")
print("*************")
print("Welcome to Swift Programming" , terminator : "-" )
print("Fall 2021")

print("The list of numbers are ")
print(1,2,3,4,5,6)
print("The new pattern is")
print(1,2,3,4,5,6, separator: "-")
