//
//  AddViewController.swift
//  Nelavelli_Quizz01
//
//  Created by Nelavelli,Chandu on 4/4/23.
//

import UIKit

class AddViewController: UIViewController {

    @IBOutlet weak var displaySumOUtlet: UILabel!
    
    var sum = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        displaySumOUtlet.text = displaySumOUtlet.text! + sum
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
