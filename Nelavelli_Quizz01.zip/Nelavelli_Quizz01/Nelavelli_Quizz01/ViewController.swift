//
//  ViewController.swift
//  Nelavelli_Quizz01
//
//  Created by Nelavelli,Chandu on 4/4/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var numOneOutlet: UITextField!
    
    @IBOutlet weak var numTwoOutlet: UITextField!
    
    var sum = 0.0
    var sub = 0.0
    var div = 0.0
    
    @IBAction func addBtn(_ sender: UIButton) {
        var num1 = Double(numOneOutlet.text!)
        var num2 = Double(numTwoOutlet.text!)
        sum = num1! + num2!
    }
    
    @IBAction func subBtn(_ sender: UIButton) {
        var num1 = Double(numOneOutlet.text!)
        var num2 = Double(numTwoOutlet.text!)
        sub = num1! - num2!
    }
    
    @IBAction func divBtn(_ sender: UIButton) {
        var num1 = Double(numOneOutlet.text!)
        var num2 = Double(numTwoOutlet.text!)
        div = num1! / num2!
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if(transition == "addSegue"){
            var destination = segue.destination as! AddViewController
            destination.sum = String(sum)
        }
        else if(transition == "subSegue"){
            var destination = segue.destination as! SubViewController
            destination.sub = String(sub)
        }
        else if(transition == "divSegue"){
            var destination = segue.destination as! DivViewController
            destination.div = String(div)
        }
        
    }


}

