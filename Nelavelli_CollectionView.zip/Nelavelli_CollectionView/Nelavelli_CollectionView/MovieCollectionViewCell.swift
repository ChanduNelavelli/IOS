//
//  MovieCollectionViewCell.swift
//  Nelavelli_CollectionView
//
//  Created by Nelavelli,Chandu on 4/20/23.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageViewOutlet: UIImageView!
    
    func assignMovie(with movie: Movie){
        imageViewOutlet.image = movie.image
    }
}
