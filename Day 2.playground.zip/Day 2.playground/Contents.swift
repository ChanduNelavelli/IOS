import UIKit

var greeting = "Hello, playground"

var mobileBrand = "Apple"
//mobileBrand = 10
print(mobileBrand)

let pi = 3.14
//pi = 2.23
print(pi)

var age : Int = 23
age = age * 2
print(age)

var aweMessage = "This is Superb!"
print(aweMessage)
print("aweMessage")

var course1 = "iOS"
var course2 = 1
print(course1,course2)
print(course1,"-",course2)

print(10,20.12,30,"hello")
print(12.5,15.5)

//var httpError  = (errorCode : 404  , errorCode : "PageNot Found")
//print(httpError)
//print(httpError.errorCode , terminator : ": ")
//print(httpError.errorMessage )

var name = ("John","John")
var fName = name.0
var lName = name.1
print(fName , terminator : ",")
print(lName)
 
var origin = (x : 0 , y : 0)
var point = origin
print(point)

let city = (name : "Maryville" , population : 11,000)
let ( cityName ,cityPopulation ) = (city.0 , city.1)
print(cityName)
print(cityPopulation)
 
let groceries = (name : "bread","onions", 12.34)
print(groceries.0)
print(groceries.1)
print(type(of: groceries))
 
var fname = "Joe"
var lname = "Root"
(fname , lname) = (lname , fname)
print("First Name is \(fname) and Last Name is \(lname)")

var cricketKit = ("handGloves" ,"helmet",("bat","ball"))
print(cricketKit.0)
print(cricketKit.1)
print(cricketKit.2.0)
print(cricketKit.2.1)

//var  firstNumber : Int = 10
//var secondNumber = 25.0
//print(secondNumber / firstNumber)

var four = 4
var finalNumber = -four
print(finalNumber)

var number1 = (😁)
var number2 = (😁)
print(number1 <  number2)
